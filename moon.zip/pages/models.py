from django.db import models

# Create your models here.
# we dont realy need much in home for db ..
# maybe for contacting but not now 
